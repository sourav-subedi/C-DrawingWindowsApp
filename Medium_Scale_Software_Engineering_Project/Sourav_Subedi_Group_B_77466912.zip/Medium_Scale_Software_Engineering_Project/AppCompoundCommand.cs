﻿using BOOSE;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MYBooseApp
{
    /// <summary>
    /// extends the base class compound command
    /// </summary>
    internal class AppCompoundCommand : CompoundCommand
    {
    }
}
